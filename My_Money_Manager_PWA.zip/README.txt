# My Money Manager — iPhone PWA

Upload all files in this folder to any HTTPS web host. Open the resulting website in Safari on iPhone, then:
Share → Add to Home Screen → turn on Open as Web App → Add.

The app stores records locally in the browser. Use the app's Backup Data button regularly.
